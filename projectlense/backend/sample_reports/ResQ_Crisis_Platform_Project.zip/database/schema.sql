CREATE TABLE incidents (id VARCHAR(36) PRIMARY KEY, severity INT, agency VARCHAR(50));
