import React from 'react';
export default function App() { return <h1>ResQ Command Center</h1>; }
