from pydantic import BaseModel
class Incident(BaseModel):
    title: str
    severity: int
    location: str
